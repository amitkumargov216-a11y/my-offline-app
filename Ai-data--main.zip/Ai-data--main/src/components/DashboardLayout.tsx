import React from 'react';
import { NavLink, Outlet } from 'react-router';
import { Home, PlusCircle, List, Search, Settings, Brain } from 'lucide-react';
import { cn } from '../lib/utils';
import { vibrate } from '../lib/haptics';

export function DashboardLayout() {
  return (
    <div className="bg-slate-900 flex md:items-center justify-center font-sans tracking-tight h-[100dvh] overflow-hidden fixed inset-0">
      <div className="w-full md:max-w-md bg-slate-50 h-full md:h-[800px] md:max-h-[100dvh] md:rounded-[48px] md:border-[12px] md:border-slate-800 relative overflow-hidden flex flex-col md:shadow-[0_25px_50px_-12px_rgba(0,0,0,0.5)]">
        
        {/* Fixed Header */}
        <header className="absolute top-0 w-full bg-white text-slate-800 p-4 shadow-sm z-50 flex items-center justify-center gap-2 border-b border-slate-100">
          <Brain className="w-6 h-6 text-indigo-600" />
          <h1 className="text-xl font-black tracking-tight"><span className="text-indigo-600">Master</span>ji.ai</h1>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto content-area p-5 pb-24 pt-20">
          <Outlet />
        </main>

        {/* Fixed Bottom Navigation */}
        <nav className="absolute bottom-0 w-full bg-white border-t border-slate-200 flex justify-around items-center h-20 pb-2 z-50 shadow-[0_-2px_4px_rgba(0,0,0,0.02)]">
          <NavItem to="/dashboard" icon={<Home size={20} />} label="Home" />
          <NavItem to="/add" icon={<PlusCircle size={20} />} label="Add" />
          <NavItem to="/entries" icon={<List size={20} />} label="Entries" />
          <NavItem to="/search" icon={<Search size={20} />} label="Search" />
          <NavItem to="/settings" icon={<Settings size={20} />} label="Settings" />
        </nav>
      </div>
    </div>
  );
}

function NavItem({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <NavLink
      to={to}
      end={to === "/dashboard"}
      onClick={() => vibrate(30)}
      className={({ isActive }) =>
        cn(
          "flex flex-col items-center justify-center w-full h-full space-y-1 text-[10px] font-semibold transition-colors cursor-pointer",
          isActive ? "text-blue-600" : "text-slate-400 hover:text-slate-600"
        )
      }
    >
      {icon}
      <span className="font-medium">{label}</span>
    </NavLink>
  );
}
