/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Navigate, useSearchParams } from 'react-router';
import { useEffect } from 'react';
import { Toaster } from 'sonner';
import { DashboardLayout } from './components/DashboardLayout';
import { Home } from './pages/Home';
import { AddEntry } from './pages/AddEntry';
import { AllEntries } from './pages/AllEntries';
import { Search } from './pages/Search';
import { Settings } from './pages/Settings';

function ReferralHandler() {
  const [searchParams] = useSearchParams();
  useEffect(() => {
    const ref = searchParams.get('ref');
    if (ref) {
      localStorage.setItem('referralCode', ref);
      localStorage.setItem('isReferred', 'true');
    }
  }, [searchParams]);
  return null;
}

export default function App() {
  return (
    <BrowserRouter>
      <ReferralHandler />
      <Toaster position="top-center" richColors />
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<Home />} />
          <Route path="/add" element={<AddEntry />} />
          <Route path="/entries" element={<AllEntries />} />
          <Route path="/search" element={<Search />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
