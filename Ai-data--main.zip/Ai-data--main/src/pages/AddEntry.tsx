import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { db, generateId } from '../db';
import { Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { vibrate } from '../lib/haptics';

export function AddEntry() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    className: '',
    subject: '',
    chapter: '',
    instruction: '',
    masterjiVoice: ''
  });
  const [solutionSteps, setSolutionSteps] = useState<string[]>(['']);
  const [loading, setLoading] = useState(false);

  const handleStepChange = (index: number, value: string) => {
    const newSteps = [...solutionSteps];
    newSteps[index] = value;
    setSolutionSteps(newSteps);
  };

  const addStep = () => {
    vibrate(20);
    setSolutionSteps([...solutionSteps, '']);
  };

  const removeStep = (index: number) => {
    vibrate(20);
    const newSteps = solutionSteps.filter((_, i) => i !== index);
    setSolutionSteps(newSteps);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    setLoading(true);
    try {
      const validSteps = solutionSteps.map(s => s.trim()).filter(Boolean);
      if (validSteps.length === 0) {
        throw new Error('At least one solution step is required.');
      }
      
      await db.entries.add({
        _id: generateId(),
        className: form.className.trim(),
        subject: form.subject.trim(),
        chapter: form.chapter.trim(),
        instruction: form.instruction.trim(),
        solutionSteps: validSteps,
        masterjiVoice: form.masterjiVoice.trim(),
        createdAt: Date.now(),
        referralCode: localStorage.getItem('referralCode') || '',
        contributorName: localStorage.getItem('contributorName') || ''
      });
      
      vibrate([30, 50, 30]);
      toast.success('Entry added successfully!');
      setForm({ className: '', subject: '', chapter: '', instruction: '', masterjiVoice: '' });
      setSolutionSteps(['']);
    } catch (err: any) {
      vibrate([50, 50, 50]);
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 pb-4">
      <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Add New Entry</h1>
      
      <form onSubmit={handleSubmit} className="bg-white p-5 rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.02)] border border-slate-200 space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1.5">Class / Grade *</label>
            <input
              required
              type="text"
              value={form.className}
              onChange={e => setForm({...form, className: e.target.value})}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm"
              placeholder="e.g. 10th"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1.5">Subject *</label>
            <input
              required
              type="text"
              value={form.subject}
              onChange={e => setForm({...form, subject: e.target.value})}
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm"
              placeholder="e.g. Math"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">Chapter *</label>
          <input
            required
            type="text"
            value={form.chapter}
            onChange={e => setForm({...form, chapter: e.target.value})}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm"
            placeholder="e.g. Algebra"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">Instruction / Question *</label>
          <textarea
            required
            rows={2}
            value={form.instruction}
            onChange={e => setForm({...form, instruction: e.target.value})}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none transition-all text-sm"
            placeholder="दो संख्याओं का योग 50 है..."
          />
        </div>

        <div>
           <label className="block text-sm font-semibold text-slate-700 mb-1.5 flex justify-between items-center">
             Solution Steps *
             <button type="button" onClick={addStep} className="text-blue-600 hover:text-blue-800 flex items-center space-x-1">
               <Plus size={14} /> <span>Add Step</span>
             </button>
           </label>
           <div className="space-y-2">
             {solutionSteps.map((step, index) => (
               <div key={index} className="flex space-x-2">
                 <span className="bg-slate-100 text-slate-500 px-3 py-2 rounded-xl text-sm font-bold">{index + 1}.</span>
                 <input
                   required
                   type="text"
                   value={step}
                   onChange={e => handleStepChange(index, e.target.value)}
                   className="flex-1 px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm"
                   placeholder="मान लेते हैं पहली संख्या..."
                 />
                 {solutionSteps.length > 1 && (
                   <button type="button" onClick={() => removeStep(index)} className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors">
                     <Trash2 size={18} />
                   </button>
                 )}
               </div>
             ))}
           </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">Masterji Voice *</label>
          <textarea
            required
            rows={3}
            value={form.masterjiVoice}
            onChange={e => setForm({...form, masterjiVoice: e.target.value})}
            className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none transition-all text-sm"
            placeholder="देखो बच्चों! हमने दो समीकरण बनाए..."
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white font-semibold py-3 rounded-xl hover:bg-blue-700 disabled:opacity-50 transition-all text-sm active:scale-[0.98] mt-2"
        >
          {loading ? 'Saving...' : 'Save Entry'}
        </button>
      </form>
    </div>
  );
}
