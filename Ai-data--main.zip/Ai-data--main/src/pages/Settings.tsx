import React, { useState, useEffect } from 'react';
import { Upload, Download, Smartphone, Brain, Share2, Users, Trash2 } from 'lucide-react';
import { db, generateId } from '../db';
import type { DatasetEntry } from '../db';
import { useLiveQuery } from 'dexie-react-hooks';
import { toast } from 'sonner';
import { vibrate } from '../lib/haptics';

export function Settings() {
  const count = useLiveQuery(() => db.entries.count(), []) || 0;
  const entriesList = useLiveQuery(() => db.entries.toArray(), []) || [];
  
  const [validCount, setValidCount] = useState(0);
  
  useEffect(() => {
     if(entriesList.length > 0) {
        const instructionMap: Record<string, boolean> = {};
        let valid = 0;
        entriesList.forEach(e => {
            const hasBadData = e.solutionSteps.length === 0 || e.solutionSteps.some((s: string) => s.trim().length === 0) || e.masterjiVoice.trim().length < 10;
            const instrLower = e.instruction.trim().toLowerCase();
            if (!hasBadData && !instructionMap[instrLower]) {
               instructionMap[instrLower] = true;
               valid++;
            }
        });
        setValidCount(valid);
     } else {
        setValidCount(0);
     }
  }, [entriesList]);

  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [referralCode, setReferralCode] = useState(localStorage.getItem('referralCode') || '');
  const [contributorName, setContributorName] = useState(localStorage.getItem('contributorName') || '');

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const isMainPhone = localStorage.getItem('isMainPhone') === 'true' || 
                      (!localStorage.getItem('isMainPhone') && localStorage.getItem('isReferred') !== 'true');

  const saveReferralCode = (code: string) => {
    if (code.toUpperCase() === 'MAINMODE') {
      localStorage.setItem('isMainPhone', 'true');
      toast.success('Main app mode activated (1M target)');
      return;
    }
    if (code.toUpperCase() === 'USERMODE') {
      localStorage.setItem('isMainPhone', 'false');
      toast.success('User mode activated (10K target)');
      return;
    }
    setReferralCode(code.toUpperCase());
    localStorage.setItem('referralCode', code.toUpperCase());
  };

  const saveContributorName = (name: string) => {
    setContributorName(name);
    localStorage.setItem('contributorName', name);
  };

  const handleShareApp = async () => {
    vibrate(20);
    if (!referralCode) {
      toast.error('Please set your referral code first');
      return;
    }
    
    // Check if running remotely. Since we don't have access to the exact shareable remote URL natively without checking window.location,
    // we use `window.location.origin` inside the browser
    const shareUrl = `${window.location.origin}/?ref=${referralCode}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'AI Library Dataset Builder',
          text: `Help me build my AI dataset! Use my referral link to install the app and contribute.`,
          url: shareUrl
        });
      } catch (err) {
        console.error(err);
      }
    } else {
      navigator.clipboard.writeText(shareUrl);
      toast.success('Referral link copied to clipboard!');
    }
  };

  const handleInstallClick = async () => {
    vibrate(20);
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    }
  };

  const [exportText, setExportText] = useState('');
  const [showExportModal, setShowExportModal] = useState(false);
  const [importContributor, setImportContributor] = useState('');

  const exportBlob = (jsonl: string, filename: string) => {
    // Also set the text for viewing
    setExportText(jsonl);
    setShowExportModal(true);
    
    // Attempt download as fallback
    try {
      const blob = new Blob([jsonl], { type: 'application/jsonl' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error("Download failed, but text is available in modal", e);
    }
  };

  const copyExportText = async () => {
    try {
      await navigator.clipboard.writeText(exportText);
      vibrate(20);
      toast.success('Data copied to clipboard!');
    } catch (e) {
      toast.error('Failed to copy. Please select all and copy manually.');
    }
  };

  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  const handleDeleteAll = async () => {
    vibrate(60);
    if (!isConfirmingDelete) {
      setIsConfirmingDelete(true);
      toast.warning('Are you sure you want to delete ALL data? Click again to confirm.', { duration: 4000 });
      return;
    }
    
    try {
      await db.entries.clear();
      setIsConfirmingDelete(false);
      vibrate([100, 100, 100]);
      toast.success('All data deleted successfully.');
    } catch (e) {
      console.error(e);
      toast.error('Failed to clear data.');
      setIsConfirmingDelete(false);
    }
  };

  const handleExportAI = async () => {
    vibrate(40);
    try {
      const records = await db.entries.toArray();
      let jsonl = '';
      let instructionMap: Record<string, number> = {};
      
      // Count instructions to identify duplicates
      records.forEach(rec => {
        const key = rec.instruction?.trim().toLowerCase() || '';
        instructionMap[key] = (instructionMap[key] || 0) + 1;
      });

      let exportedCount = 0;

      for (const rec of records) {
        // Skip bad entries
        const isBad = rec.solutionSteps.length === 0 || rec.solutionSteps.some(s => s.trim().length === 0) || rec.masterjiVoice.trim().length < 10 || !rec.instruction?.trim();
        const isDuplicate = (instructionMap[rec.instruction?.trim().toLowerCase() || ''] || 0) > 1;
        
        if (isBad || isDuplicate) continue;

        const formatted = {
          instruction: rec.instruction,
          response: {
            Solution_Steps: rec.solutionSteps.map((s, i) => `${i + 1}. ${s}`).join('\n'),
            Masterji_Voice: rec.masterjiVoice
          }
        };
        jsonl += JSON.stringify(formatted) + '\n';
        exportedCount++;
      }
      
      if (exportedCount === 0) {
        toast.error("No valid entries to export. Fix bad entries in the List tab first.");
        return;
      }
      
      exportBlob(jsonl, `ready_for_ai_training_${Date.now()}.jsonl`);
    } catch (e) {
      console.error(e);
      vibrate([50, 50, 50]);
      toast.error('AI export failed');
    }
  };

  const handleExportAll = async () => {
    vibrate(40);
    try {
      const records = await db.entries.toArray();
      if (records.length === 0) {
        toast.error("No entries found to export.");
        return;
      }
      let jsonl = '';
      for (const rec of records) {
        jsonl += JSON.stringify(rec) + '\n';
      }
      exportBlob(jsonl, `raw_backup_${Date.now()}.jsonl`);
    } catch (e) {
      console.error(e);
      vibrate([50, 50, 50]);
      toast.error('Raw export failed');
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    vibrate(40);
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter(l => l.trim().length > 0);
        let count = 0;
        const data = lines.map(line => {
           const parsed = JSON.parse(line);
           let steps: string[] = [];
           let masterji = '';
           
           if (parsed.response && parsed.response.Solution_Steps) {
             // Basic parse of '1. step \n2. step' back to array
             steps = parsed.response.Solution_Steps.split('\n').map((s: string) => s.replace(/^\d+\.\s*/, '').trim());
           } else if (parsed.solutionSteps) {
             steps = parsed.solutionSteps;
           }

           if (parsed.response && parsed.response.Masterji_Voice) {
             masterji = parsed.response.Masterji_Voice;
           } else if (parsed.masterjiVoice) {
             masterji = parsed.masterjiVoice;
           }

           count++;
           return {
             _id: parsed._id || generateId(),
             className: parsed.className || parsed.class || 'Imported',
             subject: parsed.subject || 'Imported',
             chapter: parsed.chapter || 'Imported',
             instruction: parsed.instruction || '',
             solutionSteps: steps.length > 0 ? steps : ['Imported missing step'],
             masterjiVoice: masterji || '',
             referralCode: parsed.referralCode || localStorage.getItem('referralCode') || '',
             contributorName: importContributor.trim() || parsed.contributorName || '',
             createdAt: parsed.createdAt || Date.now() + count,
           } as DatasetEntry;
        });
        
        await db.entries.bulkPut(data);
        vibrate([30, 50, 30]);
        toast.success(`Successfully imported ${data.length} entries.`);
        setImportContributor(''); // Reset after success
      } catch (err) {
        vibrate([50, 50, 50]);
        toast.error('Failed to parse JSONL file. Ensure proper format.');
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // reset
  };

  return (
    <div className="space-y-6 pb-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Settings & Data</h1>
      </div>
      
      {/* Referral Program */}
      <section className="bg-white p-5 rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.02)] border border-slate-200">
        <h2 className="text-lg font-semibold text-slate-900 mb-2 tracking-tight flex items-center">
          <Users size={18} className="mr-2 text-blue-600" /> Team & Referrals
        </h2>
        <p className="text-sm text-slate-500 mb-4">Set your active referral code. All entries you create will be tagged with this code.</p>
        
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name</label>
            <input
              type="text"
              value={contributorName}
              onChange={(e) => saveContributorName(e.target.value)}
              placeholder="e.g. John Doe"
              className="w-full px-3 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm font-semibold mb-3"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Team / Referral Code</label>
            <input
              type="text"
              value={referralCode}
              onChange={(e) => saveReferralCode(e.target.value)}
              placeholder="e.g. AMIT_123"
              className="w-full px-3 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm font-semibold uppercase"
            />
          </div>
          <button 
            onClick={handleShareApp} 
            className="w-full flex items-center justify-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold transition-colors active:scale-[0.98]"
          >
            <Share2 size={18} /> <span>Share Referral App Link</span>
          </button>
        </div>
      </section>

      {/* App Installation */}
      {deferredPrompt && (
        <section className="bg-blue-600 p-5 rounded-2xl shadow-xl border border-blue-500 text-white">
          <h2 className="text-lg font-bold mb-2 flex items-center space-x-2">
            <Smartphone size={20} />
            <span>Install App</span>
          </h2>
          <p className="text-sm text-blue-100 mb-4 font-medium leading-relaxed">
            Install this offline dataset builder directly to your phone for a native app experience.
          </p>
          <button 
            onClick={handleInstallClick} 
            className="w-full bg-white text-blue-700 py-3 rounded-xl font-bold hover:bg-slate-50 transition-colors active:scale-[0.98]"
          >
            Install App Now
          </button>
        </section>
      )}

      {/* Data Management */}
      <section className="bg-white p-5 rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.02)] border border-slate-200">
        <h2 className="text-lg font-semibold text-slate-900 mb-2 tracking-tight">Data Management & Export</h2>
        <p className="text-sm text-slate-500 mb-6">Your data is stored locally on this device. Export it frequently to train your AI.</p>
        
        <div className="space-y-3">
          <button onClick={handleExportAll} className="w-full flex items-center justify-center space-x-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 py-3 rounded-xl font-semibold transition-colors">
            <Share2 size={18} /> <span>Export All Entries (Send to Owner)</span>
          </button>
          
          <button 
            onClick={handleDeleteAll} 
            className={`w-full flex items-center justify-center space-x-2 py-3 rounded-xl font-semibold transition-all ${isConfirmingDelete ? 'bg-red-600 text-white animate-pulse' : 'bg-red-50 hover:bg-red-100 text-red-600'}`}
          >
            <Trash2 size={18} /> <span>{isConfirmingDelete ? 'CONFIRM DELETE ALL' : 'Delete All Local Entries'}</span>
          </button>
          
          <button onClick={handleExportAI} className="w-full flex items-center justify-center space-x-2 bg-green-50 hover:bg-green-100 text-green-700 py-3 rounded-xl font-semibold transition-colors">
            <Brain size={18} /> <span>View & Export Clean for AI Training</span>
          </button>
          
          <div className="pt-2 border-t border-slate-100">
            <label className="block text-xs font-semibold text-slate-700 mb-1">Received a file? Assign a team member name:</label>
            <input
              type="text"
              value={importContributor}
              onChange={(e) => setImportContributor(e.target.value)}
              placeholder="e.g. John Doe (Optional)"
              className="w-full px-3 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-sm font-semibold mb-3 bg-slate-50"
            />
            
            <label className="w-full flex items-center justify-center space-x-2 border border-dashed border-slate-300 hover:border-blue-400 hover:bg-blue-50 text-slate-700 py-3 rounded-xl font-semibold cursor-pointer transition-colors">
              <Upload size={18} /> <span>Import Dataset (JSONL)</span>
              <input type="file" accept=".jsonl" onChange={handleImport} className="hidden" />
            </label>
          </div>
        </div>
      </section>

      {/* Export Viewer Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-[32px] overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h3 className="font-bold text-slate-900 tracking-tight flex items-center">
                <Brain className="mr-2 text-indigo-600" size={20} /> Data Ready
              </h3>
              <button 
                onClick={() => setShowExportModal(false)}
                className="w-8 h-8 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>
            <div className="p-5 flex-1 overflow-y-auto bg-slate-50">
              <p className="text-xs text-slate-500 font-medium mb-3">
                Since files might not open easily on your phone, you can copy the raw data directly from here.
              </p>
              <textarea 
                readOnly
                value={exportText}
                className="w-full h-[300px] text-[10px] whitespace-pre-wrap font-mono p-3 rounded-xl border border-slate-200 bg-white text-slate-700 focus:outline-none"
              />
            </div>
            <div className="p-5 bg-white border-t border-slate-100 flex flex-col gap-3">
              <button 
                onClick={copyExportText}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl flex items-center justify-center space-x-2 transition-colors"
              >
                <span>Copy Data to Clipboard</span>
              </button>
              <button 
                onClick={() => setShowExportModal(false)}
                className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 rounded-xl flex items-center justify-center transition-colors"
              >
                Close Viewer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dataset Readiness */}
      <section className="bg-gradient-to-br from-indigo-50 to-blue-50 p-5 rounded-2xl border border-indigo-100 shadow-sm relative overflow-hidden">
         <div className="absolute top-0 right-0 p-4 opacity-10">
            <Brain size={100} />
         </div>
         <h2 className="text-lg font-semibold text-slate-900 mb-4 tracking-tight relative z-10 flex items-center">
            <Brain size={18} className="mr-2 text-indigo-600" /> Model Readiness
         </h2>
         <div className="space-y-4 relative z-10">
            <div>
               <div className="flex justify-between text-sm mb-1">
                  <span className="font-semibold text-slate-700">Valid Perfect Entries</span>
                  <span className="font-bold text-indigo-700">
                     {validCount.toLocaleString()} 
                     <span className="text-slate-400 text-xs font-normal"> / {isMainPhone ? "1M" : "10K"} Goal</span>
                  </span>
               </div>
               <div className="w-full bg-indigo-100/50 rounded-full h-2.5 overflow-hidden relative">
                  <div className="bg-indigo-600 h-2.5 rounded-full absolute top-0 left-0 transition-all duration-500" style={{ width: `${Math.min((validCount / (isMainPhone ? 1000000 : 10000)) * 100, 100)}%` }}></div>
               </div>
               <p className="text-[10px] text-slate-500 mt-1">Target: {isMainPhone ? "1,000,000" : "10,000"} valid unique entries for perfect fine-tuning</p>
            </div>

            <div className="bg-white/60 p-3 rounded-xl border border-indigo-100/50">
               <h4 className="text-xs font-bold text-indigo-900 mb-1">JSONL Engine Active</h4>
               <p className="text-[10px] text-indigo-700 leading-relaxed">
                  The dataset automatically formats "Question", "Steps" and "Explanation" into a unified valid JSONL payload required for LLM Instruction Fine-tuning.
               </p>
            </div>
         </div>
      </section>

      {/* Portfolio / About the AI */}
      <section className="bg-white p-6 rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.02)] border border-slate-200 mt-4">
        <div className="flex flex-col gap-6 items-center md:flex-row md:items-start text-center md:text-left">
          <div className="flex-shrink-0 flex flex-col items-center">
             <div className="w-32 h-32 md:w-36 md:h-36 rounded-2xl shadow-sm bg-indigo-50 border border-indigo-100 flex items-center justify-center">
                <Brain className="w-16 h-16 text-indigo-600" strokeWidth={1.5} />
             </div>
             <div className="mt-3 text-center">
               <p className="text-sm font-black text-indigo-700">Amit Kumar</p>
               <p className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5 font-bold">Founder & CEO</p>
             </div>
          </div>
          <div className="space-y-4 flex-1">
            <div>
              <h3 className="text-2xl font-black text-slate-900 leading-tight tracking-tight">Masterji.ai <span className="text-xs font-semibold text-blue-600 align-middle ml-1 bg-blue-50 px-2 py-0.5 rounded-full">Vision Module</span></h3>
            </div>
            
            <div className="space-y-3">
               <div className="text-sm text-slate-600 leading-relaxed text-justify md:text-left">
                 <span className="font-bold text-slate-800 text-xs uppercase tracking-wider block mb-1">🎯 Goal (English):</span> 
                 To create a hyper-local, syllabus-aligned Large Language Model acting as a personal 'Masterji' (teacher). Our AI will be trained strictly on verified, step-by-step educational data to provide error-free, trustworthy guidance to students, ensuring high-quality education for all.
               </div>
               
               <div className="border-t border-slate-100 pt-3 text-sm text-slate-600 leading-relaxed text-justify md:text-left">
                 <span className="font-bold text-slate-800 text-xs uppercase tracking-wider block mb-1">🎯 लक्ष्य (Hindi):</span> 
                 एक हाइपर-लोकल, पाठ्यक्रम-आधारित लार्ज लैंग्वेज मॉडल (LLM) बनाना जो छात्रों के लिए एक व्यक्तिगत 'मास्टरजी' (शिक्षक) के रूप में कार्य करेगा। हमारा एआई पूरी तरह से सत्यापित और सटीक शैक्षिक डेटा पर प्रशिक्षित किया जा रहा है, ताकि छात्रों को 100% सही और भरोसेमंद मार्गदर्शन मिल सके, और हर छात्र को बेहतरीन शिक्षा प्राप्त हो।
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
