import React, { useState, useEffect } from 'react';
import { Search as SearchIcon } from 'lucide-react';
import { DatasetEntry } from '../db';
import { db } from '../db';

export function Search() {
  const [query, setQuery] = useState('');
  const [subjectFilter, setSubjectFilter] = useState('');
  const [results, setResults] = useState<DatasetEntry[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (query || subjectFilter) {
        handleSearch();
      } else {
        setResults([]);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [query, subjectFilter]);

  const handleSearch = async () => {
    setLoading(true);
    try {
      const qLower = query.toLowerCase();
      const subjectLower = subjectFilter.toLowerCase().trim();
      
      const allEntries = await db.entries.toArray();
      
      const filtered = allEntries.filter(entry => {
        let matchQuery = true;
        let matchSubject = true;
        
        if (qLower) {
          matchQuery = 
            entry.instruction.toLowerCase().includes(qLower) ||
            entry.solutionSteps.some(s => s.toLowerCase().includes(qLower)) ||
            entry.masterjiVoice.toLowerCase().includes(qLower);
        }
        
        if (subjectLower) {
           matchSubject = entry.subject.toLowerCase().includes(subjectLower);
        }
        
        return matchQuery && matchSubject;
      });
      
      setResults(filtered as any);
      if (filtered.length > 0 && typeof navigator !== 'undefined' && navigator.vibrate) {
         navigator.vibrate(20);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 h-full flex flex-col pb-4">
      <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Search</h1>
      
      <div className="bg-white p-4 rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.02)] border border-slate-200 space-y-3 shrink-0">
        <div className="relative">
          <SearchIcon className="absolute left-3 top-2.5 text-slate-400" size={20} />
          <input
            type="text"
            className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm"
            placeholder="Search questions or solutions..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
        </div>
        <input
          type="text"
          className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-sm"
          placeholder="Filter by subject (e.g. Math)"
          value={subjectFilter}
          onChange={e => setSubjectFilter(e.target.value)}
        />
      </div>

      <div className="flex-1 overflow-y-auto space-y-3 pb-4">
        {loading && <p className="text-center text-sm font-medium text-slate-500 py-4">Searching...</p>}
        {!loading && results.length === 0 && (query || subjectFilter) && (
          <p className="text-center text-sm font-medium text-slate-500 py-4">No matching entries found.</p>
        )}
        
        {(results || []).map(entry => (
          <div key={entry._id} className="bg-white p-4 rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.02)] border border-slate-200">
             <div className="flex justify-between items-start mb-2">
                <span className="px-3 py-1 bg-amber-100 text-amber-800 rounded-xl text-[10px] font-bold tracking-wide uppercase">
                  {entry.className} • {entry.subject}
                </span>
                <span className="text-[10px] text-slate-400 font-medium">Result</span>
             </div>
             <pre className="text-[11px] font-mono text-green-400 bg-slate-800 p-3 mb-1 border border-slate-700 rounded-xl leading-relaxed overflow-x-auto">
{JSON.stringify({
  instruction: entry.instruction,
  response: {
    Solution_Steps: entry.solutionSteps.map((s, i) => `${i + 1}. ${s}`).join('\n'),
    Masterji_Voice: entry.masterjiVoice
  }
}, null, 2)}
             </pre>
          </div>
        ))}
      </div>
    </div>
  );
}
