import React, { useState, useEffect } from 'react';
import { Database, BookOpen, Clock, ChevronDown, ChevronRight, Layers, Smartphone, AlertTriangle, Brain, Users } from 'lucide-react';
import { db } from '../db';
import { useLiveQuery } from 'dexie-react-hooks';
import { vibrate } from '../lib/haptics';

export function Home() {
  const stats = useLiveQuery(async () => {
    const totalEntries = await db.entries.count();
    const entries = await db.entries.toArray();
    
    // Group by Class -> Subject -> Chapter -> Count
    const tree: Record<string, Record<string, Record<string, number>>> = {};
    let totalSubjects = 0;
    const subjectSet = new Set<string>();

    const instructionMap: Record<string, any[]> = {};
    const problematic: any[] = [];
    const referralStats: Record<string, { total: number, valid: number, duplicate: number, bad: number, names: Set<string> }> = {};

    entries.forEach(e => {
      // Track referrals
      const ref = e.referralCode?.toUpperCase() || 'SELF/UNKNOWN';
      if (!referralStats[ref]) {
         referralStats[ref] = { total: 0, valid: 0, duplicate: 0, bad: 0, names: new Set() };
      }
      referralStats[ref].total += 1;
      if (e.contributorName?.trim()) {
         referralStats[ref].names.add(e.contributorName.trim());
      }


      // Check for bad data
      const hasBadData = e.solutionSteps.length === 0 || e.solutionSteps.some(s => s.trim().length === 0) || e.masterjiVoice.trim().length < 10;
      if (hasBadData) {
        problematic.push({ type: 'Bad Data', entry: e });
        referralStats[ref].bad += 1;
      } else {
        // Check for duplicates
        const instrLower = e.instruction.trim().toLowerCase();
        if (!instructionMap[instrLower]) instructionMap[instrLower] = [];
        instructionMap[instrLower].push({ entry: e, ref });
      }
    });

    const duplicates: any[] = [];
    let validEntriesCount = 0;

    Object.values(instructionMap).forEach(list => {
      if (list.length > 1) {
        validEntriesCount += 1;
        referralStats[list[0].ref].valid += 1; // Mark the first one as valid
        
        for (let i = 1; i < list.length; i++) {
            duplicates.push({ type: 'Duplicate', entry: list[i].entry });
            referralStats[list[i].ref].duplicate += 1; // Mark the rest as duplicates
        }
      } else {
        validEntriesCount += 1;
        referralStats[list[0].ref].valid += 1;
      }
    });

    // Populate tree based only on valid items
    const problematicIds = new Set(problematic.map(p => p.entry._id));
    const duplicateIds = new Set(duplicates.map(d => d.entry._id));
    
    entries.forEach(e => {
        if (!problematicIds.has(e._id) && !duplicateIds.has(e._id)) {
          if (!tree[e.className]) tree[e.className] = {};
          if (!tree[e.className][e.subject]) tree[e.className][e.subject] = {};
          tree[e.className][e.subject][e.chapter] = (tree[e.className][e.subject][e.chapter] || 0) + 1;
          subjectSet.add(e.subject);
        }
    });
    
    // Sort descending by createdAt
    const recentActivity = entries.sort((a, b) => b.createdAt - a.createdAt).slice(0, 5);
    
    return {
      totalEntries,
      validEntriesCount,
      duplicateCount: duplicates.length,
      badDataCount: problematic.length,
      totalSubjects: subjectSet.size,
      tree,
      recentActivity,
      issues: [...duplicates, ...problematic],
      referralStats
    };
  }, []);

  const [expandedClasses, setExpandedClasses] = useState<Record<string, boolean>>({});
  const toggleClass = (c: string) => {
    vibrate(20);
    setExpandedClasses(prev => ({...prev, [c]: !prev[c]}));
  };

  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstallClick = async () => {
    vibrate(20);
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    }
  };

  return (
    <div className="space-y-6 pb-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center space-x-2">
          <span>AI Library Overview</span>
        </h1>
        <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center">🔔</div>
      </div>

      {deferredPrompt && (
        <section className="bg-blue-600 p-5 rounded-2xl shadow-xl border border-blue-500 text-white mb-6">
          <h2 className="text-lg font-bold mb-2 flex items-center space-x-2">
            <Smartphone size={20} />
            <span>Install App on Phone</span>
          </h2>
          <p className="text-sm text-blue-100 mb-4 font-medium leading-relaxed">
            Install this dataset builder directly to your phone for a fast, offline native app experience.
          </p>
          <button 
            onClick={handleInstallClick} 
            className="w-full bg-white text-blue-700 py-3 rounded-xl font-bold hover:bg-slate-50 transition-colors active:scale-[0.98]"
          >
            Install App Now
          </button>
        </section>
      )}
      
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-blue-600 p-4 rounded-2xl text-white flex flex-col justify-center">
          <Database className="mb-2 opacity-80" size={24} />
          <div className="text-2xl font-bold">{stats?.totalEntries || 0}</div>
          <div className="text-sm opacity-80">Total Entries</div>
        </div>
        <div className="bg-slate-800 p-4 rounded-2xl text-white flex flex-col justify-center">
          <BookOpen className="mb-2 opacity-80" size={24} />
          <div className="text-2xl font-bold">{stats?.totalSubjects || 0}</div>
          <div className="text-sm opacity-80">Total Subjects</div>
        </div>
      </div>

      {/* Referral Leaderboard */}
      {stats?.referralStats && Object.keys(stats.referralStats).length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-bold mb-3 text-slate-900 tracking-tight flex items-center">
            <Users className="mr-2 text-indigo-600" size={16} /> Team Contributions
          </h3>
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-[0_2px_4px_rgba(0,0,0,0.02)] space-y-3">
            {Object.entries(stats.referralStats)
              .sort((a, b) => b[1].valid - a[1].valid)
              .map(([refCode, counts], idx) => (
              <div key={refCode} className="flex flex-col bg-slate-50 p-3 rounded-xl border border-slate-100 gap-2">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${idx === 0 ? 'bg-amber-100 text-amber-700' : 'bg-slate-200 text-slate-600'}`}>
                      #{idx + 1}
                    </div>
                    <div className="flex flex-col">
                      <span className="font-bold text-sm text-slate-800">{refCode}</span>
                      {counts.names.size > 0 && (
                        <span className="text-[10px] text-slate-500 font-semibold line-clamp-1 max-w-[120px]" title={Array.from(counts.names).join(', ')}>
                          {Array.from(counts.names).join(', ')}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center space-x-1">
                    <span className="text-lg font-black text-indigo-600">{counts.valid}</span>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase mt-1">Valid</span>
                  </div>
                </div>
                <div className="flex justify-end gap-3 text-[10px] font-semibold">
                  <span className="text-orange-500">{counts.duplicate} Duplicates</span>
                  <span className="text-red-500">{counts.bad} Errored</span>
                  <span className="text-slate-400">({counts.total} Total)</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {stats?.tree && Object.keys(stats.tree).length > 0 && (
        <div className="mb-6 space-y-3">
          <h3 className="text-sm font-bold mb-3 text-slate-900 tracking-tight flex items-center">
            <Layers className="mr-2" size={16} /> Entries Organization
          </h3>
          
          {Object.entries(stats.tree).map(([className, subjects]) => {
            const isExpanded = expandedClasses[className];
            const totalInClass = Object.values(subjects).reduce((acc, chapters) => 
               acc + Object.values(chapters).reduce((sum, count) => sum + count, 0), 0
            );

            return (
              <div key={className} className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-[0_2px_4px_rgba(0,0,0,0.02)]">
                <button 
                  onClick={() => toggleClass(className)}
                  className="w-full flex items-center justify-between p-4 bg-slate-50/50 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    {isExpanded ? <ChevronDown size={18} className="text-slate-400" /> : <ChevronRight size={18} className="text-slate-400" />}
                    <span className="font-bold text-slate-800 text-sm">{className}</span>
                  </div>
                  <span className="px-2.5 py-1 bg-amber-100 text-amber-800 text-xs font-bold rounded-lg">{totalInClass} Entries</span>
                </button>
                
                {isExpanded && (
                  <div className="p-4 pt-2 space-y-4 border-t border-slate-100 bg-white">
                    {Object.entries(subjects).map(([subject, chapters]) => {
                      const totalInSubject = Object.values(chapters).reduce((sum, count) => sum + count, 0);
                      
                      return (
                        <div key={subject} className="pl-2 border-l-2 border-indigo-100">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-bold text-indigo-900 ml-2">{subject}</span>
                            <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md font-semibold">{totalInSubject} Total</span>
                          </div>
                          
                          <div className="ml-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
                             {Object.entries(chapters).map(([chapter, count]) => (
                               <div key={chapter} className="flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-100/50">
                                  <span className="text-xs font-semibold text-slate-700 truncate mr-2" title={chapter}>
                                    {chapter}
                                  </span>
                                  <span className="text-[10px] bg-white text-slate-500 border border-slate-200 px-2 py-0.5 rounded-lg font-bold">
                                    {count}
                                  </span>
                               </div>
                             ))}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {stats?.issues && stats.issues.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-bold mb-3 text-red-600 tracking-tight flex items-center">
            <AlertTriangle className="mr-2" size={16} /> Data Issues ({stats.issues.length})
          </h3>
          <div className="space-y-2">
            {stats.issues.slice(0, 10).map((issue, idx) => (
              <div key={issue.entry._id || idx} className="bg-red-50 border border-red-100 rounded-xl p-3">
                 <div className="flex justify-between items-start mb-1">
                   <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-lg text-[10px] font-bold tracking-wide uppercase">
                     {issue.type}
                   </span>
                   <span className="text-[10px] text-red-400 font-bold">{issue.entry.className} • {issue.entry.subject}</span>
                 </div>
                 <p className="text-xs font-semibold text-red-900 line-clamp-2 mt-1">{issue.entry.instruction}</p>
                 {issue.type === 'Bad Data' && (
                    <p className="text-[10px] text-red-600 mt-1">Steps or Masterji Voice is missing/too short.</p>
                 )}
              </div>
            ))}
            {stats.issues.length > 10 && (
              <p className="text-xs text-red-500 font-semibold text-center pt-2">
                + {stats.issues.length - 10} more issues found
              </p>
            )}
          </div>
        </div>
      )}

      <div>
        <h3 className="text-sm font-bold mb-3 text-slate-900 tracking-tight">Recent Activity</h3>
        
        <div className="space-y-3">
          {(stats?.recentActivity || []).map((entry, idx) => (
            <div key={entry._id || idx} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-[0_2px_4px_rgba(0,0,0,0.02)]">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center space-x-2">
                  <span className="px-3 py-1 bg-amber-100 text-amber-800 rounded-xl text-[10px] font-bold tracking-wide uppercase">
                    {entry.className}
                  </span>
                  <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-xl text-[10px] font-bold tracking-wide uppercase">
                    {entry.subject}
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-medium flex items-center"><Clock size={10} className="mr-1"/> Recent</span>
              </div>
              <p className="font-semibold text-sm text-slate-900 line-clamp-2 leading-relaxed mt-2">{entry.instruction}</p>
              <p className="text-xs text-slate-500 mt-1 font-medium line-clamp-1">{entry.chapter}</p>
            </div>
          ))}
          {(!stats?.recentActivity || stats.recentActivity.length === 0) && (
             <p className="text-sm text-slate-500 text-center py-4 font-medium">No recent activity.</p>
          )}
        </div>
      </div>
    </div>
  );
}
