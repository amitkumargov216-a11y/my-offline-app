import React, { useState, useEffect, useMemo } from 'react';
import { DatasetEntry } from '../db';
import { Trash2, Edit2, X, Check, Filter } from 'lucide-react';
import { db } from '../db';
import { useLiveQuery } from 'dexie-react-hooks';
import { toast } from 'sonner';
import { vibrate } from '../lib/haptics';

export function AllEntries() {
  const [page, setPage] = useState(1);
  const limit = 20;

  const [filterStatus, setFilterStatus] = useState<'all' | 'valid' | 'bad' | 'duplicate'>('all');
  const [filterContributor, setFilterContributor] = useState<string>('');

  // Fetch all entries to do complex filtering (like duplicates across the whole DB)
  const allEntries = useLiveQuery(() => db.entries.orderBy('createdAt').reverse().toArray()) || [];
  
  const processedEntries = useMemo(() => {
    const instructionMap: Record<string, number> = {};
    
    // First pass: count instruction occurrences for duplication
    allEntries.forEach(e => {
      const key = e.instruction?.trim().toLowerCase() || '';
      instructionMap[key] = (instructionMap[key] || 0) + 1;
    });

    return allEntries.map(e => {
      const isBad = e.solutionSteps.length === 0 || e.solutionSteps.some(s => s.trim().length === 0) || e.masterjiVoice.trim().length < 10 || !e.instruction?.trim();
      const isDuplicate = (instructionMap[e.instruction?.trim().toLowerCase() || ''] || 0) > 1;
      
      return {
        ...e,
        _isBad: isBad,
        _isDuplicate: isDuplicate,
        _isValid: !isBad && !isDuplicate
      };
    });
  }, [allEntries]);

  const contributors = useMemo(() => {
    const set = new Set<string>();
    allEntries.forEach(e => e.contributorName && set.add(e.contributorName));
    return Array.from(set).sort();
  }, [allEntries]);

  const filteredEntries = useMemo(() => {
    let result = processedEntries;

    if (filterContributor) {
      result = result.filter(e => e.contributorName === filterContributor);
    }

    if (filterStatus === 'valid') result = result.filter(e => e._isValid);
    if (filterStatus === 'bad') result = result.filter(e => e._isBad);
    if (filterStatus === 'duplicate') result = result.filter(e => e._isDuplicate);

    return result;
  }, [processedEntries, filterStatus, filterContributor]);

  const displayedEntries = filteredEntries.slice(0, page * limit);
  const totalPages = Math.ceil(filteredEntries.length / limit);

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<DatasetEntry>>({});
  const [editSolutionSteps, setEditSolutionSteps] = useState<string[]>([]);

  const handleDelete = async (id: string) => {
    vibrate(40);
    if (!confirm('Delete this entry?')) return;
    try {
      await db.entries.delete(id);
      vibrate([30, 50, 30]);
      toast.success('Entry deleted');
    } catch (e) {
      console.error(e);
      vibrate([50, 50, 50]);
      toast.error('Failed to delete');
    }
  };

  const startEdit = (entry: DatasetEntry) => {
    vibrate(20);
    setEditingId(entry._id!);
    setEditForm(entry);
    setEditSolutionSteps([...entry.solutionSteps]);
  };

  const handleUpdate = async () => {
    if (!editingId) return;
    try {
      const payload = {
        ...editForm,
        solutionSteps: editSolutionSteps.map(s => s.trim()).filter(Boolean)
      } as any;
      delete payload._id;
      delete payload._isBad;
      delete payload._isDuplicate;
      delete payload._isValid;

      await db.entries.update(editingId, payload);
      setEditingId(null);
      vibrate([30, 50, 30]);
      toast.success('Entry updated');
    } catch (e) {
      console.error(e);
      vibrate([50, 50, 50]);
      toast.error('Failed to update');
    }
  };

  return (
    <div className="space-y-4 pb-4">
      <div className="flex flex-col mb-4 bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center mb-4">
          <Filter className="mr-2 text-indigo-600" size={20} /> Advanced Filter
        </h1>
        
        <div className="space-y-3">
          <div>
             <label className="text-xs font-semibold text-slate-500 mb-1 block">Status</label>
             <div className="flex space-x-2 overflow-x-auto pb-1 hide-scrollbar">
                {(['all', 'valid', 'bad', 'duplicate'] as const).map(status => (
                  <button 
                    key={status}
                    onClick={() => { setFilterStatus(status); setPage(1); }}
                    className={`px-4 py-2 rounded-xl text-xs font-bold capitalize transition-colors whitespace-nowrap ${filterStatus === status ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                  >
                    {status} ({processedEntries.filter(e => {
                        if (status === 'all') return true;
                        if (status === 'valid') return e._isValid;
                        if (status === 'bad') return e._isBad;
                        if (status === 'duplicate') return e._isDuplicate;
                        return true;
                    }).length})
                  </button>
                ))}
             </div>
          </div>

          <div>
             <label className="text-xs font-semibold text-slate-500 mb-1 block">Contributor (Names added during backup)</label>
             <select 
               value={filterContributor} 
               onChange={(e) => { setFilterContributor(e.target.value); setPage(1); }}
               className="w-full px-3 py-2.5 text-sm font-semibold border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none appearance-none bg-slate-50"
             >
                <option value="">All Contributors</option>
                {contributors.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
             </select>
          </div>
        </div>
      </div>
      
      <div className="text-sm font-semibold text-slate-500 px-1">
         Showing {filteredEntries.length} entries
      </div>

      <div className="space-y-4">
        {displayedEntries.map((entry: any) => (
          <div key={entry._id} className={`bg-white p-4 rounded-2xl shadow-[0_2px_4px_rgba(0,0,0,0.02)] border flex flex-col ${entry._isBad ? 'border-red-300 bg-red-50/30' : entry._isDuplicate ? 'border-amber-300 bg-amber-50/30' : 'border-slate-200'}`}>
            {editingId === entry._id ? (
              <div className="space-y-3">
                <input type="text" className="w-full px-3 py-2 text-sm font-semibold border border-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg" value={editForm.className || ''} onChange={e => setEditForm({...editForm, className: e.target.value})} placeholder="Class"/>
                <input type="text" className="w-full px-3 py-2 text-sm font-semibold border border-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg" value={editForm.subject || ''} onChange={e => setEditForm({...editForm, subject: e.target.value})} placeholder="Subject"/>
                <input type="text" className="w-full px-3 py-2 text-sm font-semibold border border-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg" value={editForm.chapter || ''} onChange={e => setEditForm({...editForm, chapter: e.target.value})} placeholder="Chapter"/>
                <textarea className="w-full px-3 py-2 text-sm font-semibold border border-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg resize-none" rows={2} value={editForm.instruction || ''} onChange={e => setEditForm({...editForm, instruction: e.target.value})} placeholder="Instruction"/>
                
                <h4 className="text-xs font-bold text-slate-500 uppercase tracking-widest mt-2 mb-1">Steps (Joined by newline on export)</h4>
                <textarea 
                  className="w-full px-3 py-2 text-sm border border-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg resize-none font-mono" 
                  rows={4} 
                  value={editSolutionSteps.join('\n')} 
                  onChange={e => setEditSolutionSteps(e.target.value.split('\n'))} 
                  placeholder="Solution Steps (one per line)"
                />

                <textarea className="w-full px-3 py-2 text-sm font-semibold border border-slate-300 outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg resize-none" rows={3} value={editForm.masterjiVoice || ''} onChange={e => setEditForm({...editForm, masterjiVoice: e.target.value})} placeholder="Masterji Voice"/>
                
                <div className="flex justify-end space-x-2 pt-2">
                   <button onClick={() => setEditingId(null)} className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200">
                     <X size={18} />
                   </button>
                   <button onClick={handleUpdate} className="px-4 py-2 font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center space-x-1">
                     <Check size={18} /> <span>Save Fix</span>
                   </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex flex-wrap gap-1">
                     {entry._isBad && <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded-lg text-[9px] font-bold tracking-wide uppercase border border-red-200">Needs Fix</span>}
                     {entry._isDuplicate && <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-lg text-[9px] font-bold tracking-wide uppercase border border-amber-200">Duplicate</span>}
                     {entry._isValid && <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-lg text-[9px] font-bold tracking-wide uppercase border border-emerald-200">Valid</span>}
                  </div>
                  
                  <div className="flex space-x-2 shrink-0">
                    <button onClick={() => startEdit(entry)} className="text-slate-400 hover:text-indigo-600 transition-colors bg-white rounded-md p-1 border border-slate-200">
                      <Edit2 size={16} />
                    </button>
                    <button onClick={() => handleDelete(entry._id!)} className="text-slate-400 hover:text-red-600 transition-colors bg-white rounded-md p-1 border border-slate-200">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
                
                <pre className="text-[11px] font-mono text-green-400 bg-slate-800 p-3 mb-3 border border-slate-700 rounded-xl leading-relaxed overflow-x-auto whitespace-pre-wrap">
{JSON.stringify({
  instruction: entry.instruction,
  response: {
    Solution_Steps: entry.solutionSteps.map((s: string, i: number) => `${i + 1}. ${s}`).join('\n'),
    Masterji_Voice: entry.masterjiVoice
  }
}, null, 2)}
                </pre>
                
                <div className="flex flex-wrap items-center justify-between mt-auto pt-2 border-t border-slate-100/50">
                   <div className="flex flex-wrap gap-1">
                     <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md text-[10px] font-semibold border border-slate-200 uppercase">
                       {entry.className}
                     </span>
                     <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md text-[10px] font-semibold border border-slate-200 uppercase">
                       {entry.subject}
                     </span>
                   </div>
                   {entry.contributorName && (
                     <div className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md border border-indigo-100">
                       By: {entry.contributorName}
                     </div>
                   )}
                </div>
              </>
            )}
          </div>
        ))}
        {displayedEntries.length === 0 && (
          <p className="text-center text-slate-500 py-10 font-medium text-sm">No entries found matching filters.</p>
        )}
      </div>

      {page < totalPages && (
        <button
          onClick={() => setPage(page + 1)}
          className="w-full py-3 mt-4 text-indigo-600 font-bold text-sm bg-indigo-50 hover:bg-indigo-100 rounded-xl active:scale-[0.98] transition-all border border-indigo-100"
        >
          Load More (+{Math.min(limit, filteredEntries.length - page * limit)})
        </button>
      )}
    </div>
  );
}
