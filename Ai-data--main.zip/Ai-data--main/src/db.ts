import Dexie, { Table } from 'dexie';

export interface DatasetEntry {
  _id?: string;
  className: string;
  subject: string;
  chapter: string;
  instruction: string;
  solutionSteps: string[];
  masterjiVoice: string;
  createdAt: number;
  referralCode?: string;
  contributorName?: string;
}

export class AppDB extends Dexie {
  entries!: Table<DatasetEntry, string>;

  constructor() {
    super('DatasetBuilderDB');
    this.version(4).stores({
      entries: '_id, className, subject, chapter, instruction, createdAt, referralCode, contributorName'
    });
  }
}

export const db = new AppDB();

export const generateId = () => {
    return Date.now().toString(36) + Math.random().toString(36).substring(2);
};
